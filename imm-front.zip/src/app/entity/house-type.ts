export class HouseType {
  id;
  houseTypeName;
}
