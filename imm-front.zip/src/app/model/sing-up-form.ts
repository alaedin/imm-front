export class SingUpForm {

  username: string;
  password: string;
  email: string;
  name: string;
  role = [];
}
