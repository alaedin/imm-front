export class LoginForm {

  username: string;
  password: string;
}
